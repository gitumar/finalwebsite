const { app, BrowserWindow, Notification } = require('electron')

var size = 100000;

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600
  })

  win.loadFile('index.html')
}

var NOTIFICATION_TITLE = 'Basic Notifications'
var NOTIFICATION_BODY = 'Notification from the Main process'

function showNotification(sortingAlgorithm, clientTime) {
  //new Notification({ title: NOTIFICATION_TITLE, body: NOTIFICATION_BODY }).show()
  new Notification({ title: sortingAlgorithm + " Took:", body: clientTime.toString() + "ms" }).show()
}

app.whenReady().then(createWindow).then(doSorts)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})

function doSorts() {
  var arr = giveMeArray(size);
  var sortingAlgorithm = "Quicksort";
  
  var t0 = performance.now();
  quickSortJS(arr)
  var t1 = performance.now();
  var clientTime = t1 - t0;
  showNotification(sortingAlgorithm, clientTime.toFixed(3));

  arr = giveMeArray(size);
  sortingAlgorithm = "Mergesort";
  t0 = performance.now();
  mergeSort(arr, 0, size - 1);
  t1 = performance.now();
  clientTime = t1 - t0;
  showNotification(sortingAlgorithm, clientTime.toFixed(3));

  arr = giveMeArray(size);
  sortingAlgorithm = "Insertionsort";
  t0 = performance.now();
  insertionSortJs(arr, size)
  t1 = performance.now();
  clientTime = t1 - t0;
  showNotification(sortingAlgorithm, clientTime.toFixed(3));


}

function quickSortJS(arr) {
  if (arr.length < 2) {
    return arr;
  }
  const pivot = arr[Math.floor(Math.random() * arr.length)];

  let left = [];
  let right = [];
  let equal = [];

  for (let val of arr) {
    if (val < pivot) {
      left.push(val);
    } else if (val > pivot) {
      right.push(val);
    } else {
      equal.push(val);
    }
  }
  return [
    ...quickSortJS(left),
    ...equal,
    ...quickSortJS(right)
  ];
}
/**
* @param  {array} arr The array that is to be sorted.
* @param  {int} l The starting index
* @param  {int} m The middle index
* @param  {int} r The ending index
*/
function merge(arr, l, m, r) {
  var n1 = m - l + 1;
  var n2 = r - m;

  // Create temp arrays
  var L = new Array(n1);
  var R = new Array(n2);

  // Copy data to temp arrays L[] and R[]
  for (var i = 0; i < n1; i++)
    L[i] = arr[l + i];
  for (var j = 0; j < n2; j++)
    R[j] = arr[m + 1 + j];

  // Merge the temp arrays back into arr[l..r]

  // Initial index of first subarray
  var i = 0;

  // Initial index of second subarray
  var j = 0;

  // Initial index of merged subarray
  var k = l;

  while (i < n1 && j < n2) {
    if (L[i] <= R[j]) {
      arr[k] = L[i];
      i++;
    }
    else {
      arr[k] = R[j];
      j++;
    }
    k++;
  }

  // Copy the remaining elements of
  // L[], if there are any
  while (i < n1) {
    arr[k] = L[i];
    i++;
    k++;
  }

  // Copy the remaining elements of
  // R[], if there are any
  while (j < n2) {
    arr[k] = R[j];
    j++;
    k++;
  }
}
/**
* @param  {array} arr The array that is to be sorted.
* @param  {int} l The starting index
* @param  {int} r The ending index
*/
function mergeSort(arr, l, r) {
  if (l >= r) {
    return;//returns recursively
  }
  var m = l + parseInt((r - l) / 2);
  mergeSort(arr, l, m);
  mergeSort(arr, m + 1, r);
  merge(arr, l, m, r);
}
/**
* @param  {array} arr The array that is to be sorted.
* @param  {int} n The size of the array being sorted.
*/
function insertionSortJs(arr, n) {
  let i, key, j;
  for (i = 1; i < n; i++) {
    key = arr[i];
    j = i - 1;

    while (j >= 0 && arr[j] > key) {
      arr[j + 1] = arr[j];
      j = j - 1;
    }
    arr[j + 1] = key;
  }
  //console.log(arr);
}
/**
* @param  {int} size The size of the array being initialized.
*/
function giveMeArray(size) {
  var arr = new Array(size);

  for (let index = 0; index < size; index++) {
    arr[index] = Math.floor(Math.random() * 100) + 1;
  }
  return arr;

}